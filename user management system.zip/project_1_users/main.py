from db import get_connection, init_db

def demo():
    conn = get_connection()
    init_db(conn)
    print("Database and `users` table created.")
    conn.close()

if __name__ == "__main__":
    demo()
